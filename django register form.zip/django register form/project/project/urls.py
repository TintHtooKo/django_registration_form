
from django.contrib import admin
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.register,name='register'),
    path('login/',views.loginPage,name='login'),
    path('home/',views.homePage, name='home'),
    path('logout',views.logoutPage,name='logout')
]
